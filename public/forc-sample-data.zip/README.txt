FOR-C Sample Network Data
=========================
Know Before The Line Stops  |  for-c.com

This package contains a ready-to-run supply chain simulation dataset
representing a 7-facility automotive electronics network. Upload all
files to the FOR-C dashboard and click Run Simulation to see the
platform in action immediately.

──────────────────────────────────────────
NETWORK OVERVIEW
──────────────────────────────────────────

  [SUPPLIER_A_ASIA]  ─┐
  [SUPPLIER_B_ASIA]  ─┼──► [DISTRIBUTOR_US] ──► [TIER1_PLANT_A] ──► [ASSEMBLY_PLANT_US]
  [SUPPLIER_C_ASIA]  ─┘                     └──► [TIER1_PLANT_B] ──►

  3 Tier 3 suppliers (Asia) feed a US distributor, which supplies
  2 Tier 1 assembly plants, which deliver 2 finished modules to
  1 OEM assembly plant.

  Finished goods:  MODULE_A (50 units/day demand)
                   MODULE_B (35 units/day demand)

  Active disruption: SUPPLIER_A_ASIA — 100% outage for 65 days
  Expected result:   Service level drops to ~55%, TTR ~38 days

──────────────────────────────────────────
FILES INCLUDED
──────────────────────────────────────────

  demand.csv              Daily customer demand by SKU (90-day window)
  locations.csv           Facility registry with coordinates and tier
  bom.csv                 Bill of materials (parent-component relationships)
  processes.csv           Production capacity by facility and SKU
  location_materials.csv  On-hand inventory by facility and SKU at sim start
  lanes.csv               Transportation lanes with lead times  [optional]
  disruptions.csv         Active disruption scenario

──────────────────────────────────────────
HOW TO RUN YOUR FIRST SIMULATION
──────────────────────────────────────────

  1. Open the FOR-C Simulation Dashboard
  2. Upload all 7 CSV files using the input panel
  3. Name the run (e.g. "Supplier A Outage — Baseline")
  4. Click Run Simulation
  5. Review results in the Impact Summary tab

──────────────────────────────────────────
HOW TO CUSTOMIZE FOR YOUR NETWORK
──────────────────────────────────────────

  Replace facility names     Edit locations.csv — all IDs must match across files
  Change demand volumes      Edit Quantity column in demand.csv
  Test a different outage    Edit disruptions.csv — change facility, dates, severity
  Adjust inventory buffers   Edit quantity column in location_materials.csv
  Add transit routes         Add rows to lanes.csv

  Column definitions and valid values are documented in the
  comment block at the top of each CSV file.

──────────────────────────────────────────
SUPPORT
──────────────────────────────────────────

  Book a demo:  https://calendar.app.google/M8cXnzMvXqaj63sA7
  Website:      https://for-c.com

  FOR-C  |  Supply Chain Intelligence
